# SNHVideoEditor
a tool to trim,merge,add watermasks with videos
