//
//  SNHVideoTrimmerController.h
//  NiuCam
//
//  Created by huangshuni on 2017/7/13.
//  Copyright © 2017年 Mirco. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface SNHVideoTrimmerController : UIViewController

@property (nonatomic, strong) NSURL *videoUrl;


@end
