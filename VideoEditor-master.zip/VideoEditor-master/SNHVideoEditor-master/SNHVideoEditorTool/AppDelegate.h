//
//  AppDelegate.h
//  SNHVideoEditorTool
//
//  Created by huangshuni on 2017/7/26.
//  Copyright © 2017年 huangshuni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

