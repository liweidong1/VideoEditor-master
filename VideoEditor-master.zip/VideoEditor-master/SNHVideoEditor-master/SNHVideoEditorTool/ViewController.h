//
//  ViewController.h
//  SNHVideoEditorTool
//
//  Created by huangshuni on 2017/7/26.
//  Copyright © 2017年 huangshuni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

