//
//  NSString+TimeConvert.h
//  SNHVideoEditorTool
//
//  Created by huangshuni on 2017/7/27.
//  Copyright © 2017年 huangshuni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (TimeConvert)

+(NSString *)getCurrentTime;

@end
