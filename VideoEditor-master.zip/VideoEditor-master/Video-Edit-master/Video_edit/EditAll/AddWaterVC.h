//
//  AddWaterVC.h
//  Video_edit
//
//  Created by xiaoke_mh on 16/4/7.
//  Copyright © 2016年 m-h. All rights reserved.
//

#import "CommentVideoVC.h"

@interface AddWaterVC : CommentVideoVC

@end
