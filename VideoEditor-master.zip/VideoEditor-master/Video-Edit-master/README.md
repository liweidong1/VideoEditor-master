# Video-Edit
视频剪辑：添加水印，裁剪，合并，添加背景音乐

AVFoundation
CoreMedia
ZYQAssetPickerController 
